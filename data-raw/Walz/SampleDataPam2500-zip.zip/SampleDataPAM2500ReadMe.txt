Sample data for PAM-2500 software PamWin-3 (V3.05c)

(1)
Make sure that software PamWin-3 (V3.05c) or higher is installed.

(2)
Sample data are provided in the PamWin-3 format as directory.
The sample directory is named �20091204�.
Copy the entire directory �20091204� (with files) to
C:\PamWin_3\Data_2500\Report\

(4)
Start PamWin-3 in VIEW MODE and open report �20091204�.
(Note that the report name is equivalent to the directory name.)

(5)
The report �20091204� contains 5 records:

Record 1: light curve with saturation pulse analysis.
Record 2: induction curve and recovery with saturation pulse analysis.
Record 3: polyphasic fluorescence rise
Record 4: single turnover flash-induced fluorescence kinetics
Record 5: multiple turnover flash-induced fluorescence kinetics

Switch between records using the arrows in the middle of the
side panel of the PamWin-3 window.

View record 1 in slow kinetics or light curve window.

Record 2 can only be viewed in the slow kinetics window.

To view fluorescence kinetics induced by saturation pulses,
(record 1 and 2) check �SP� and scroll through kinetics using
the arrow pair on top of the window.

Records 3 to 5 are displayed in the fast kinetics window
after the FK has been checked.
